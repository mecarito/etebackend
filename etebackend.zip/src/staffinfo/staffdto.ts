
export class Staffdto {

     firstName: string;
     middleName: string;
     lastName: string;
     mobileNumber: number
     telephoneNumber: string
     staffId: number
     email: string;
     website: string;
     position: string;
     highestEducation: string;
     researchGroup: string;
     officeNo: string;
     administrativeRole: string;
     selectedData: string[];
     length;

}