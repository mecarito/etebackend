
export class Studentdto {

    firstname: string;
    lastname: string;
    age: number;
    degree: string;
    year: number;

}